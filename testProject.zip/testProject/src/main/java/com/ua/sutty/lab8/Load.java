package com.ua.sutty.lab8;

import interfaces.task4.MapUtils;
import interfaces.task8.PathClassLoader;

public class Load {

    public static void main(String[] args) throws ClassNotFoundException {


        ClassLoader classLoader = Load.class.getClassLoader();

        PathClassLoader classLoader1 = new PathClassLoaderImpl();
        classLoader.loadClass("/home/NIX/suttyread/Desktop/send/2/src/main/java/com/ua/sutty/lab1/task_1/Main.java");



    }

}
