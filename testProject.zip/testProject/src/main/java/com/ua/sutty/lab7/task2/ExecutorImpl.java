package com.ua.sutty.lab7.task2;

import interfaces.task7.executor.Executor;
import interfaces.task7.executor.TasksStorage;

public class ExecutorImpl implements Executor {

    private TasksStorage tasksStorage;

    public ExecutorImpl(TasksStorage tasksStorage) {
        this.tasksStorage = tasksStorage;
    }

    @Override
    public void setStorage(TasksStorage tasksStorage) {
        this.tasksStorage = tasksStorage;
    }

    @Override
    public TasksStorage getStorage() {
        return this.tasksStorage;
    }

    @Override
    public void start() {

    }

    @Override
    public void stop() {

    }
}
