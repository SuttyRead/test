package com.ua.sutty.lab7.task2;

import interfaces.task7.executor.CopyTask;

public class CopyTaskImpl implements CopyTask {
    @Override
    public void setSource(String s) {

    }

    @Override
    public void setDest(String s) {

    }

    @Override
    public int getTryCount() {
        return 0;
    }

    @Override
    public void incTryCount() {

    }

    @Override
    public boolean execute() throws Exception {
        return false;
    }
}
